package main

import (
	"fmt"
	"io"
	"net"
	"net/http"
	"crypto/tls"
	"os/exec"
	"regexp"
	"time"
)

func main() {
	http.DefaultTransport.(*http.Transport).TLSClientConfig = &tls.Config{InsecureSkipVerify: true}
	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintln(w, "OK")
	})

	http.HandleFunc("/status-check", func(w http.ResponseWriter, r *http.Request) {
		url := r.FormValue("url")
		match, _ := regexp.MatchString(`^(https?:\/\/)?ctf.uscybergames\.com`, url)
		if !match {
			http.Error(w, "URL not allowed", http.StatusBadRequest)
			return
		}

		client := http.Client{
			Timeout: 3 * time.Second,
		}
		resp, err := client.Get(url)
		if err != nil || resp.StatusCode != 200 {
			fmt.Fprintln(w, "down")
			return
		}
		defer resp.Body.Close()
		io.Copy(io.Discard, resp.Body)
		fmt.Fprintln(w, "up")
	})

	http.HandleFunc("/admin/exec", func(w http.ResponseWriter, r *http.Request) {
		ip, _, _ := net.SplitHostPort(r.RemoteAddr)
		if ip != "127.0.0.1" && ip != "::1" {
			http.Error(w, "Forbidden", http.StatusForbidden)
			return
		}

		cmdStr := r.URL.Query().Get("cmd")
		if cmdStr == "" {
			http.Error(w, "Missing cmd", http.StatusBadRequest)
			return
		}

		cmd := exec.Command("sh", "-c", cmdStr)
		err := cmd.Run()
		if err != nil {
			w.WriteHeader(500)
			fmt.Fprintln(w, "Command failed")
			return
		}
		fmt.Fprintln(w, "OK")
	})

	http.ListenAndServe(":8080", nil)
}
