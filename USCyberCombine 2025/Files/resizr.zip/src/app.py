from io import BytesIO
import subprocess
from flask import Flask, request, abort, send_file, render_template_string

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024  # 10 MB max upload

FORM_HTML = """<!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Resizr</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head><body class="bg-light">
<div class="container py-5">
  <h1 class="mb-3">Resizr</h1>
  <p class="text-muted">Upload a PNG image and get it resized!</p>
  <form method="post" action="/upload" enctype="multipart/form-data" class="card p-3 shadow-sm">
    <div class="mb-3">
      <label class="form-label" for="file">Image file</label>
      <input class="form-control" type="file" id="file" name="file" required>
    </div>
    <button class="btn btn-primary">Process</button>
  </form>
</div>
</body></html>"""

@app.get("/")
def index():
    return render_template_string(FORM_HTML)

@app.post("/upload")
def upload():
    file = request.files.get("file")
    if not file:
        abort(400, "no file")

    data = file.read()
    if not data:
        abort(400, "empty file")
    try:
        proc = subprocess.run(
            ["magick", "-", "-resize", "50%", "png:-"],
            input=data,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=True,
            timeout=15,
        )
    except subprocess.CalledProcessError as e:
        abort(500, f"ImageMagick error: {e.stderr.decode('utf-8', 'ignore')[:500]}")
    except subprocess.TimeoutExpired:
        abort(504, "processing timed out")

    out = proc.stdout
    if not out:
        abort(500, "no output produced")

    return send_file(BytesIO(out), mimetype="image/png", download_name="out.png", as_attachment=True)
    
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)
